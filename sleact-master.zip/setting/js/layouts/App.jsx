import React from 'react';

const App = () => {
  return <div>초기 세팅입니다.</div>;
};

export default App;
